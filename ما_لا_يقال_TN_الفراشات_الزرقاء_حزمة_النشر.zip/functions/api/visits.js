import {cookieRole,json} from './_utils.js';
export async function onRequestGet({request,env}){const role=await cookieRole(request,env);if(role!=='owner')return json({error:'غير مسموح'},403);const {results}=await env.DB.prepare('SELECT at FROM visits ORDER BY id DESC LIMIT 100').all();return json({visits:results||[]});}
